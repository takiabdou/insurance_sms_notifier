# =============================================================
# main.py — Point d'entrée CRMA Notify SMS
# =============================================================

from gui.dashboard import CRMASMSApp

if __name__ == "__main__":
    app = CRMASMSApp()
    app.mainloop()